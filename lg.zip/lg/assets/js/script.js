$(document).ready(function(){
	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + "/" + getUrl.pathname.split('/')[1] + "/";




	$('#but').click(function(){
		var url = $("#url").val();
	    if (url != "") {
	    	$.ajax( {
				url: baseUrl+'links/add',
	            type: "post",
	            data: $('form').serialize(),
	            success: function(d) {
	            	$('.result').slideDown('slow');
	            	$('.result a').attr('href', d);	
	            	// $('#preview').attr('src', d);	                	
	            	$('#result').html(d);
	            }
			});
	    }

	});


	$('input.link').blur(function(){
		var f = $(this).closest('form');
	    var r = confirm("Are you sure you want to update this link?");
	    if (r == true) {
	    	$.ajax( {
				url: baseUrl+'links/update',
	            type: "post",
	            data: f.serialize(),
	            success: function(d) {
	            	// alert("Updated")
	            	alert(d)
	            }
			});
	    }
	});


	$('.dellink').click(function(){
		var id = $(this).find('.lid').val();
		var tr = $(this).closest('tr');
	    var r = confirm("Are you sure you want to delete this link?");
	    if (r == true) {	    	
	    	$.ajax( {
				url: baseUrl+'links/delete',
	            type: "post",
	            data: "id=" + id,
	            success: function(d) {
	            	$(tr).remove();
	            }
			});
	    }

	});





	$( ".validateme" ).submit(function( event ) {
		var error = "";
		$(".req").each(function(){
			if($(this).val() == ""){
				var thisid = $(this).attr("id"); 
				error = error + "<div class='pad5'><strong>"+thisid + "</strong> is required. </div>";
			}
		}).promise().done(function(){
			if(error != ""){
				$("#mask").show();
				$("#error_cont").show();
				$("#append").html(error);
			}else{				
				$( ".validateme" ).submit();
			}
		});

		return false;
	});


	$(".int").keydown(function (e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
            (e.keyCode == 65 && ( e.ctrlKey === true || e.metaKey === true ) ) || 
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 return;
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });


	$("#Type").change(function(){
		$("body").css("cursor", "wait");
		var lnk = "";
		if($(this).val() == 1){
			lnk = "others/static_page";
		}
		else if($(this).val() == 2){
			lnk = "others/articles";
		}
		else if($(this).val() == 3){
			lnk = "others/article_category";
		}


		if($(this).val() == 0){
			$("#Page").html("<option value='0'>#</option>");
		}
		else if($(this).val() <= 3){
			$.ajax( {
				url: baseUrl + lnk,
	            success: function(d) {
	            	$("#Page").html(d);
					$("body").css("cursor", "default");
	            }
			});
		}

	});


	// MAGIC TABS

	$('.newtab').find('li').click(function(){
		$('.newtab').find('li').removeClass('active');
		$(this).addClass('active');

		var act = $(this).attr('id');
		$('.tab').hide();
		$('.'+act).show();

	});



	$("#mask").click(function(){
		$(this).hide();
		$("#error_cont").hide();
	});
	$(".close").click(function(){
		$("#mask").hide();
		$("#error_cont").hide();
	});

	$(".date").datetimepicker({
		language: 'pt-BR',
        changeMonth: true,
        changeYear: true,
        yearRange: "-100:"
	});


var autoSelect = function(event) {
  var event = event || window.event, 
      elem = event.target || event.srcElement, 
      tag = (elem.tagName || "").toLowerCase(), 
      sel, range;
  
  if (tag === "textarea" || tag === "input") {
    try {
      elem.select();
    } catch(e) {
      // May be disabled or not selectable
    }
  } else if (window.getSelection) { // Not IE
    sel = window.getSelection();
    range = document.createRange();
    range.selectNodeContents(elem);
    sel.removeAllRanges();
    sel.addRange(range);
  } else if (document.selection) { // IE
    document.selection.empty();
    range = document.body.createTextRange();
    range.moveToElementText(elem);
    range.select();
  }
};

document.getElementById("result").onclick = autoSelect;

});
