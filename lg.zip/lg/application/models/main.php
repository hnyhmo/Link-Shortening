<?php
class Main extends CI_Model {

	function insert($data, $table){
		$this->db->insert($table, $data); 
	}

	function update($id, $data, $table){
		$this->db->where('id', $id);
		$this->db->update($table, $data); 
	}

	function delete($id, $table){
		$this->db->where('id', $id);
		$this->db->delete($table); 
	}

	function all($table){
		$r = $this->db->get($table);
		return $r->result();
	}

	function select($id, $table){
		$this->db->where('id', $id);
		$r = $this->db->get($table);
		return $r->result();
	}

	function select_some($sample, $id, $table){
		$this->db->where($sample, $id);
		$r = $this->db->get($table);
		return $r->result();
	}

	function limit($table='', $per_pg='', $offset='', $year, $course, $student_no, $orderby = '', $dasc='')
    {
 		if($orderby != '' and $dasc != ''){
			$this->db->order_by($orderby, $dasc);
 		}

 		if($year !=''){
 			$this->db->where('year', $year);
 		}
 		if($course !=''){
 			$this->db->where('course', $course);
 		}
 		if($student_no !=''){
 			$this->db->like('student_number', $student_no);
 		}

        $query=$this->db->get($table,$per_pg,$offset);
        return $query->result();
    }

}