<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Link Generator</title>
	<link href="//fonts.googleapis.com/css?family=Roboto:400,300" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/app.css" rel="stylesheet">	
	<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
</head>

<body>

<div class="container" id="login">
	<div class="panel panel-default">
		<div class="panel-heading bold">Link Generator</div>
		<div class="panel-body">
			<?php if(validation_errors() != ""){ ?>
				<div class="alert alert-danger">
			   		<?php echo validation_errors(); ?>
			   	</div>
			<?php } ?>
			<div class="form-horizontal">
			   <?php echo form_open('verify'); ?>
			   	<div class="form-group">
				    <label for="username" class="col-md-4 control-label">Username:</label>
				    <div class="col-md-6">
				     	<input type="text" size="20" id="username" name="username" class="form-control"/>
				    </div>
				</div>
				<div class="form-group">
				    <label for="password" class="col-md-4 control-label">Password:</label>
				    <div class="col-md-6">
				     	<input type="password" size="20" id="passowrd" name="password" class="form-control"/>
				    </div>
				</div>
			    <div class="form-group">
			    	<div class="col-md-6 col-md-offset-4 text-right">
				    	<input type="submit" value="Login" class="btn btn-default"/>
				    </div>
			    </div>
			   </form>
			</div>
		<div>
	</div>
</div>

</body>
</html>