
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Link Generator</title>	
	<link href="<?php echo base_url(); ?>assets/css/app.css" rel="stylesheet">	
	<link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
	<link href="<?php echo base_url(); ?>assets/css/date.css" rel="stylesheet">
	<script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/date.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/script.js"></script>
</head>

<body>
<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle Navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo base_url(); ?>" target="">Link Generator</a>
			</div>

			<?php 
				$session_data = $this->session->userdata('logged_in');
			    $user_id = $session_data['id'];
			   	$user_data = $this->db->query("select * from users where id='".$user_id."'")->result();

			?>

			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav">
					<li><a href="<?php echo base_url();?>links">Links</a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><?php echo $user_data[0]->firstname.' '.$user_data[0]->lastname; ?> <span class="caret"></span></a>
						<ul class="dropdown-menu" role="menu">
							<li><a href="<?php echo base_url(); ?>home/logout">Logout</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>
</nav>

<div class="container">
	<div class="panel panel-default">
		<div class="panel-heading">
			<div class="row">
				<div class="col-xs-12">
					<h3><?php if(isset($title)){echo $title;} ?></h3>
				</div>	
				<!-- <div class="col-xs-6 text-right right-head">
					<?php if(isset($rtitle)){echo $rtitle;} ?>
				</div> -->
			</div>
		</div>
		<div class="panel-body">
			<?php if(isset($vfile) != ""){ $f = BASE."/application/views/".$vfile; include($f); } ?>
		</div>
	</div>
</div>

<div id="mask" class="none"></div>
<div id="error_cont" class="none">
	<h2>Oops</h2>
	<div id="append"></div>
	<img class="close" src="<?php echo base_url() ;?>/assets/images/delete.png" />
</div>

</body>
</html>