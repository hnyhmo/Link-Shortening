<table class="table">
	<tr>
		<!-- <th></th> -->
		<th>Generated Link</th>
		<th>Original Link</th>
		<th>Options</th>
	</tr>
<?php

foreach ($links as $l) {
			// <td><input type='checkbox' name='link[]' value='".$l->id."' /></td>
	echo "<tr>
			<td><a href='".base_url().'l/'.$l->id."' target='_blank'>".base_url().'l/'.$l->id."</a></td>
			<td><form><input type='hidden' name='id' value='".$l->id."' /><input type='text' class='form-control link' name='link' value='".$l->orig_link."' /></form></td>
			<td><a href='javascript:void(0)' class='btn btn-danger dellink'>Delete<input type='hidden' class='lid' value='".$l->id."' /></a></td>
		</tr>";
}

?>
</table>