<div class="table-responsive max600">
	<?php if(count($menu) <= 0){echo "No Data Found.";}else{ ?>
	  <table class="table">
	  	<tr><th>Sort</th><th>Name</th><th>Type</th><th>Options</th></tr>
		<?php
			foreach ($menu as $men) {
				echo "<tr>
						<td>".$men->sort."</td>
						<td>".$men->name."</td><td>";
						if($men->type == 1){
							echo "Static Page";
						}
						else if($men->type == 2){
							echo "Article Page";
						}
						else if($men->type == 3){
							echo "Article Category Page";
						}
						else{
							echo "#";
						}

				echo "</td><td class='options'>
							<a href='".base_url()."menu/edit/".$men->id."' class='edit'><img src='".base_url()."assets/images/edit.png' alt='edit'/></a>
							<a href='javascript:void(0)' class='delete'><img src='".base_url()."assets/images/delete.png' alt='delete'/><input type='hidden' value='".$men->id."' /></a>
						</td>
					</tr>";
			}
		?>
	<?php } ?>

	<input type="hidden" id="link" value="<?php echo base_url(); ?>menu/delete" />
</div>