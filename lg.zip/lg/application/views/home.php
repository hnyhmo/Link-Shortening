<div class="row max680">
	<form method='post' action="<?php echo base_url(); ?>links/add"  >
		<div class="col-sm-10"><input type='text' class="form-control" id="url" placeholder="Paste URL" name='url' /></div>
		<div class="col-sm-2"><button id="but" type='button' class="btn btbn-default">Generate</button></div>

		<div class='clearfix'></div>
		<br>
		<div class='result text-center clearfix none'>
			<h4>New URL : <span class='green' id='result'></span> 
			<br><br>
			<a href="" target='_blank'>Visit Link</a> </h4><br>
			<!-- <img id="preview" alt='No Preview' class='max100per'/> -->
		</div>
	</form>


</div>