<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Links extends CI_Controller {

	public function index(){
		if($this->session->userdata('logged_in'))
		{
		    $session_data = $this->session->userdata('logged_in');
		    $data['username'] = $session_data['username'];
		    $data['links'] = $this->db->query('select * from links order by id desc')->result();
		    $data['vfile'] = 'links.php';
		    $this->load->view('template', $data);
		}
	   else
	   {
	     redirect('login', 'refresh');
	   }
	}

	public function add(){
		if($this->session->userdata('logged_in'))
		{
		    if(isset($_POST)){
		    	$data = array(
		    		'link' => 'lg'.uniqid(),
		    		'orig_link' => $this->input->post('url'),
		    	);
		    	$this->main->insert($data, 'links');
		    	$last = $this->db->insert_id();
		    	$lnk = $this->main->select($last, 'links');
		    	echo base_url().'l/'.$lnk[0]->id;
		    }
		}
	   else
	   {
	     redirect('login', 'refresh');
	   }
	}

	public function update(){
	    if(isset($_POST['id'])){
	    	$data['orig_link'] = $_POST['link'];	    	
	    	$this->main->update($_POST['id'], $data, 'links');
	    }
	}

	public function delete(){
		if($this->session->userdata('logged_in'))
		{
		    if(isset($_POST)){		    	
		    	$this->main->delete($_POST['id'], 'links');
		    }
		}
	   else
	   {
	     redirect('login', 'refresh');
	   }
	}

}