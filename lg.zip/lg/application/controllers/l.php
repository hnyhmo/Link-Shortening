<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class L extends CI_Controller {

	public function index()
	{
		$url = $this->uri->segment(2);
		$find = $this->main->select($url, 'links');
		if(count($find) >= 1){
			$redi = $find[0]->orig_link;
			redirect($redi);
		}
	}
}