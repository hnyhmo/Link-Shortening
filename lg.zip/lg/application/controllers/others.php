<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Others extends CI_Controller {
	
	function static_page(){
		$result = $this->main->all("static_pages");
		$string = "";
		foreach ($result as $re) {
			$string .= "<option value='".$re->id."'>".$re->name."</option>";
		}
		echo $string;
	}

	function articles(){
		$result = $this->main->all("articles");
		$string = "";
		foreach ($result as $re) {
			$string .= "<option value='".$re->id."'>".$re->name."</option>";
		}
		echo $string;
	}

	function article_category(){
		$result = $this->main->all("article_categories");
		$string = "";
		foreach ($result as $re) {
			$string .= "<option value='".$re->id."'>".$re->name."</option>";
		}
		echo $string;
	}

}