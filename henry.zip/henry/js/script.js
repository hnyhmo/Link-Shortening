$(document).ready(function(){
	$('button').click(function(){
		var u = $('#url').val();
		if(u == ""){
			alert("Please add a url");
		}else{
			$.ajax({
				url: '/henry/welcome/add',
				type: 'post',
				data: $("form").serialize(),
				success: function(d){
					$("#orig").html(u);
					$("#result").html(d);
					$(".none").show('slow');
				}
			});
		}
	});
});