<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>URL Shortening</title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/bootstrap.css" />
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/style.css" />
	<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>js/script.js"></script>
</head>
<body>

<div id="container">
	<div class='row max'>
		<form>
			<div class="form-group"> 
				<input type="text" class="form-control" id="url"  name='url' placeholder="Paste or Type URL here.."> 
			</div>
			<div class="form-group text-right"> 
				<button type='button' class='btn btn-default'>Submit</button>
			</div>
		</form>
		<div class='text-center none'>
			<p>Original URL : <span class='b' id='orig'></span></p>
			<p>Shorten URL : <span class='b' id='result'></span></p>
		</div>
	</div>
</div>

</body>
</html>